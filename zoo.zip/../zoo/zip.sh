zip -r -q ../zoo.zip ../zoo --exclude=*target* --exclude=*/.*
mv ../zoo.zip zoo.zip 
